@extends('layouts.app')

<div id="page-wrapper" >
    <div class="header">
        <h2 class="page-header">
            Form Inputs Page
        </h2>
        <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li><a href="#">Forms</a></li>
            <li class="active">Data</li>
        </ol>

    </div>
</div>
