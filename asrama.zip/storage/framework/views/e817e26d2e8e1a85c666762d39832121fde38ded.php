<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <!-- Custom page header alternative example-->
        <div class="d-flex justify-content-between">
            <div class="mr-4 mb-3 mb-sm-0">
                <h1 class="mb-0">Data Mahasiswa</h1>
            </div>
            <!-- Date range picker example button-->
            <div class="btn btn-white btn-sm line-height-normal p-3" >
                <span>
                <h5>Total Mahasiswa :  <strong class="text-danger"><?php echo e($mahasiswa->count()); ?></strong> Orang </h5>
                    </span>
            </div>
        </div>
    </div>
    <div class="container mt-1">

        <div class="card">
            <div class="card-body">
                <table class="table table-hover table-bordered table-sm" id="datatable">
                    <thead style="text-align: center">
                    <tr>
                        <th>No</th>
                        <th>Nim</th>
                        <th>Nama</th>
                        <th>Aksi</th>
                    </tr>
                    </thead>
                    <tbody style="text-align: center" >
                    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($a -> nim); ?></td>
                            <td><?php echo e($a -> nama); ?></td>
                            <td>
                                <a class="btn btn-outline-indigo btn-sm legitRipple" href="<?php echo e(route('denda',[$a -> user_id])); ?>">Denda</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('script'); ?>
            <script>
                $(document).ready( function () {
                    $('#datatable').DataTable();
                } );
            </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\asrama\resources\views/pembina/checkout/denda/datadenda.blade.php ENDPATH**/ ?>