<div class="modal fade" id="edit_tugasbulananmhs" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Tugas Bulanan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="form_edit_tugasbulananmhs" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">
                            Nama Tugas
                        </label>
                        <select class="custom-select select2" id="edittugas" name="tugas">
                            <option value="">Pilih Tugas</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">
                            Keterangan
                        </label>
                        <select class="custom-select select2" name="keterangan" id="editketerangan">
                            <option value="">Pilih Keterangan</option>
                            <option value="Belum Selesai">Belum Selesai</option>
                            <option value="Selesai">Selesai</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline-danger legitRipple" type="button" data-dismiss="modal">
                    Close
                </button>
                <button class="btn btn-primary" type="button" id="submit_edit_tugasbulananmhs" aksi="input">Submit
                </button>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\laragon\www\asrama\resources\views/pembina/checkout/tugas/modal/_edit_tugas_bulanan_mahasiswa.blade.php ENDPATH**/ ?>