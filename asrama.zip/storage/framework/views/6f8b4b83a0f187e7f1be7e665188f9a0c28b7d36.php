<?php $__env->startSection('content'); ?>
    <div class="container mt-1">
        <div class="card">
            <div class="card-header">Tugas</div>
            <div class="card-body">
                <table class="table table-hover table-green-soft table-sm table-bordered" id="table">
                    <thead class="text-center">
                    <tr>
                        <th>Nama Tugas</th>
                        <th>Bulan</th>
                        <th>Tahun</th>
                        <th>Keterangan</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->nama_tugas); ?></td>
                        <td><?php echo e($data->bulan); ?></td>
                        <td><?php echo e($data->tahun); ?></td>
                        <td><?php echo e($data->keterangan); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready( function () {
            $('#table').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\asrama\resources\views/mahasiswa/checkout/tugas.blade.php ENDPATH**/ ?>