

<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container mt-1">
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-3">
                    <div class="card card-header-actions h-100">
                        <div class="card-header">
                            <div class="d-flex justify-content-between">
                            <h2 class="text-blue"><?php echo e($data->judul); ?>

                            </div>
                            <div class="d-flex justify-content-between font-italic ">
                             <small> <?php echo e(date('j F, Y',strtotime($data->waktu_post))); ?> </small>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php echo e(Str::limit($data->keterangan,100)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\asrama\resources\views/mahasiswa/postinganmahasiswa.blade.php ENDPATH**/ ?>