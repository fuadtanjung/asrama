<?php $__env->startSection('content'); ?>
    <div class="container mt-1">
        <div class="card" style="width: 70%">
            <div class="card-header">Kamar Asrama</div>
            <div class="card-body">
                <?php if( !$room): ?>
                    <h2>Anda Belum punya kamar</h2>
                <?php else: ?>
                    <h4 class="text-info">Anda Berada Di :</h4>
                    <div class="row">
                        <div class="col-xxl-6 col-xl-6 mb-2">
                            <h2 class="text-dark">Kamar : <?php echo e($kamar->nama_ruangan); ?></h2>
                            <h2 class="text-dark">Gedung Asrama : <?php echo e($kamar->nama_gedung); ?></h2>
                        </div>
                        <div class="col-xxl-6 col-xl-6 mb-2">
                            <h3 class="text-primary">Mulai : <?php echo e(date('d F Y',strtotime($kamar->mulai ))); ?></h3>
                            <h3 class="text-primary">Akhir : <?php echo e(date('d F Y',strtotime($kamar->akhir ))); ?></h3>
                        </div>
                    </div>
                <p>Tolong upload Surat Perjanjian Anda. Anda dapat dapat mendownload Surat tersebut pada menu <b>Surat Asrama</b></p>
                <form action="<?php echo e(route('suratperjanjian',[$kamar->ruangan_id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if( count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div>
                            <input type="file" name="file" id="chooseFile">
                        </div>

                        <button type="submit" name="submit" class="btn btn-primary btn-lg mt-3">
                            <b>Upload Files</b>
                        </button>
                    </form>
                <div>
                    <?php endif; ?>
                    <br>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\asrama\resources\views/mahasiswa/kamar.blade.php ENDPATH**/ ?>