<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content />
    <meta name="author" content />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>SIRAMU</title>
   <link rel="icon" type="image/x-icon" href="<?php echo e(url('assets/favicon.png')); ?>" />
    <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(url('plugins/izitoast/css/iziToast.min.css')); ?>">
    <link href="<?php echo e(url('css/tempusdominus-bootstrap-4.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(url('js/font-awesome/all.js')); ?>"></script>

</head>

<body>
    <?php echo $__env->yieldContent('navbar'); ?>
<!-- Scripts -->

    <script src="<?php echo e(url('js/jquery-3.5.1.js')); ?>"></script>
    <script src="<?php echo e(url('js/jquery.datetimepicker.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/script.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/izitoast/js/iziToast.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/custom.js')); ?>"></script>
    <script src="<?php echo e(url('js/datetime.js')); ?>"></script>
<!-- izitoast -->
<?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\asrama\resources\views/layouts/app.blade.php ENDPATH**/ ?>