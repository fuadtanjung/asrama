

<?php $__env->startSection('content'); ?>
    <div class="container mt-1">
        <div class="card" style="width: 70%">
            <form>
                <div class="card-body" style="margin-right: 10%">
                    <table class="table table-hover table-green-soft" id="datatable">
                        <thead>
                        <tr>
                            <th>Nama Mahasiswa</th>
                            <th>Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $checkroom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->nama); ?></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('unduh',[$data->ruangan_id,$data->mahasiswa_id])); ?>">Surat Perjanjian</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready( function () {
            $('#datatable').DataTable();

            <?php if(Session::has('failed')): ?>
                iziToast.error({
                title: 'Gagal',
                position: 'topRight',
                message: "Surat Perjanjian Mahasiswa Belum Diupload",
                timeout :'2500',
                transitionIn: 'flipInX',
                transitionOut: 'flipOutX'
                });
            <?php endif; ?>
        } );
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\asrama\resources\views/pembina/checkin/checkroom.blade.php ENDPATH**/ ?>